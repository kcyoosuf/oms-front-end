import React from "react";
import { Route, Switch, Redirect } from "react-router";
import asyncComponent from "../components/AsyncComponent";
const Home = asyncComponent(() => import("../pages/home"));
const Productlisting = asyncComponent(() => import("../pages/productlisting"));

export default () => (

  <Switch>
    <Route exact path="/" component={Home} />
    <Route exact path="/:page" component={Home} />
    <Route exact path="/categories/:category" component={Productlisting} />
  </Switch>
);
