import { createMuiTheme } from "@material-ui/core/styles";

const theme = createMuiTheme({
  palette: {
    primary: {
      main: "#9a0036"
    },
    secondary: {
      main: "#009688"
    }
  },
  typography: {
    useNextVariants: true
  }
});
export default theme;
