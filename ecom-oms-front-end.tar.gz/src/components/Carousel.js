import React from 'react';
import Carousel from 'react-material-ui-carousel'
import { Card, CardActionArea, CardMedia, Grid } from '@material-ui/core'
import { makeStyles } from '@material-ui/core/styles';
const useStyles = makeStyles({
    carousel: {

        
    },
});
export default ({ items }) => {
    const classes = useStyles();
    return (
        <Carousel indicators={false} autoPlay interval={4000} animation="slide" className={classes.carousel}>
            {items.map((item, index) => {
                return (
                    <Grid container spacing={1} style={{ marginTop: 8 }} key={index}>
                        <Grid item xs={12} md={12} lg={12} key={index}>
                            <Card>
                                <CardActionArea>
                                    <CardMedia
                                        component="img"
                                        alt="Contemplative Reptile"
                                        image={item.imageUrl}
                                        title="Contemplative Reptile"
                                    />
                                </CardActionArea>
                            </Card>
                        </Grid>
                    </Grid>
                )
            })
            }
        </Carousel>
    )
}
