
import React, { useEffect } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import { Box } from '@material-ui/core';
import IconButton from '@material-ui/core/IconButton';
import FavoriteBorderIcon from '@material-ui/icons/FavoriteBorder';
import AddShoppingCartIcon from '@material-ui/icons/AddShoppingCart';
const useStyles = makeStyles(theme => ({

    card_container: {
        "backgroundColor": "#ffffff",
        "padding": "10px",
        "transition": "all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)",
        //"boxShadow": "2px 1px 3px 3px rgba(0, 0, 0, 0.12), 2px 1px 2px 3px rgba(0, 0, 0, 0.24)",
        '&:hover': {
            "boxShadow": "0 14px 14px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22)",
            marginRight:2,
            marginLeft:2
        },
        overflow: "hidden",
        [theme.breakpoints.down('md')]: {
            margin: 1,
        },
    },
    card: {
        "display": "flex",
        "flexDirection": "column",
        "position": "relative",
        textDecoration: "none",
        cursor: "pointer"
    },
    item_image_container: {
        "height": "100%",
        display: "flex",
        "margin": "0 auto",
    },
    item_image: {
        "top": "0",
        "left": "0",
        "bottom": "0",
        "right": "0",
        "maxWidth": "100%",
        "maxHeight": "100%",
        "transition": "opacity 0.5s linear",
        "opacity": "1",
        "margin": "auto",
        "zIndex": "0"
    },
    favorite_icon: {
        "position": "absolute",
        "right": "0px",
        zIndex: 1
    },
    cart_icon: {

        [theme.breakpoints.up('lg')]: {
            zIndex: 1,
            position: "absolute",
            "bottom": "0px",
            "right": "0px",
        },
        [theme.breakpoints.down('md')]: {

            position: "absolute",
            zIndex: 1,
            "left": "0px",
            "top": "0px",
        },

    },

    sub_title: {
        "display": "inline-block",
        "width": "calc(100% - 200px)",
        "textOverflow": "ellipsis",
        "whiteSpace": "nowrap",
        "overflow": "hidden",
        "color": "#212121"
    },
    title: {
        "color": "#878787",
        "fontSize": "14px",
        "fontWeight": "500"
    },
    item_price: {
        display: "flex",
        paddingTop: 3
    },
    price: {

        "fontSize": "16px",
        "fontWeight": "500",
        "color": "#212121"
    },
    actual_price: {

        "marginLeft": "8px",
        "textDecoration": "line-through",
        "fontSize": "14px",
        "color": "#878787",
        "lineHeight": "1.5"
    },
    discount: {
        "color": "#388e3c",
        "fontSize": "13px",
        "letterSpacing": "-0.2px",
        "fontWeight": "500",
        "display": "inline-block",
        "marginLeft": "8px",
        "lineHeight": "1.5"
    },
    rating: {
        lineHeight: "normal",
        "display": "inline-block",
        color: "#fff",
        "padding": "2px 4px 2px 6px",
        borderRadius: 3,
        fontWeight: 500,
        fontSize: 12,
        verticalAlign: "middle",
        backgroundColor: "#388e3c",
    },
    totalrating: {
        "display": "inline-block",
        paddingLeft: 8,
        fontWeight: 500,
        color: "#878787",
        "padding": "2px 4px 2px 6px",
        verticalAlign: "middle",
    }

}))
export default ({ product }) => {

    const classes = useStyles();
    const [expanded, setExpanded] = React.useState(false);
    const handleExpandClick = () => {
        setExpanded(!expanded);
    };
    return (

        <div className={classes.card_container}>
            <div className={classes.card} href="">
                <Box
                    display="flex"
                    flexWrap="wrap"
                    alignContent="flex-end"
                    bgcolor="background.paper"
                    css={{ height: 350 }}
                >
                    <div calss="favorite-icon-container">
                        <IconButton className={classes.cart_icon} aria-label="add to shopping cart" color="secondary">
                            <AddShoppingCartIcon />
                        </IconButton>
                        <IconButton className={classes.favorite_icon} aria-label="add to shopping cart" color="primary">
                            <FavoriteBorderIcon />
                        </IconButton>
                    </div>
                    <div className={classes.item_image_container} onClick={(e) => { e.stopPropagation(); alert("Hiii") }}>
                        <img
                            className={classes.item_image}
                            src={product.imageUrl}
                        />
                    </div>
                </Box>
                <Box
                    display="flex"
                    flexWrap="wrap"
                    alignContent="flex-end"
                    bgcolor="background.paper"
                    css={{ height: 100 }}
                >
                    <div className={classes.item_details}>
                        <div className={classes.item_desc}>
                            <div className={classes.title}>{product.title}</div>
                            <div className={classes.sub_title}>
                                {product.subtitle}
                            </div>
                        </div>

                        {product.rating && (
                            <>
                                <div className={classes.rating}>&#9733;{product.rating.ratingValue}</div>
                                <div className={classes.totalrating}>{`(${product.rating.total_ratings})`}</div>
                            </>
                        )}


                        <div className={classes.item_price}>
                            <div className={classes.price}>{`₹${product.price}`}</div>
                            <div className={classes.actual_price}>{`₹${product.actual_price}`}</div>
                            <div className={classes.discount}>{`${product.offer_percentage} off`}</div>
                        </div>

                    </div>
                </Box>
            </div>
        </div>
    )
}