import React, { useEffect, useState } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import { useSelector, useDispatch } from 'react-redux';
import { fetchCategories } from '../core/actions/ui-actions';
import { push } from 'connected-react-router'
import { Hidden } from '@material-ui/core';
import clsx from 'clsx';


const useStyles = makeStyles(theme => ({
    topNavigation: {
        minHeight: "40px",
        boxShadow: "0 1px 1px 0 rgba(0,0,0,.16)",
        backgroundColor: "#FFF",
    },
    container: {
        color: "#212121",
        textAlign: "center",
        position: "relative",
        maxWidth: "1248px",
        margin: "0 auto",
    },
    navigationUl: {
        listStyleType: "none",
        marginBlockStart:0,
        display: "flex",
        justifyContent: "space-between"
    },
    menuItem: {
        float: "left",
        flex: 3,
        fontWeight: 500,
        paddingTop:10,
        '&:hover': {
            color: "brown",
            fontWeight: 800,
            cursor: "pointer"
        }
    },
    active: {
        color: "brown",
    }
}));
export default () => {
    const classes = useStyles();
    const [active, setActive] = useState("top_stories")
    const categories = useSelector(state => state.ui.categories);
    const dispatch = useDispatch();

    useEffect(() => {
        if (categories.length === 0) {
            dispatch(fetchCategories())
        }
    })
    return (
        <Hidden smDown>
            <div className={classes.topNavigation}>
                <div className={classes.container}>
                    <ul className={classes.navigationUl}>
                        {
                            categories && categories.map(item => (
                                <li
                                    key={item.name}
                                    className={active === item.name ? clsx(classes.active, classes.menuItem) : classes.menuItem}
                                    onClick={() => {
                                        setActive(item.name)
                                        dispatch(push(`/categories${item.url}`))
                                    }}
                                >
                                    {item.title}
                                </li>
                            ))

                        }

                    </ul>
                </div>
            </div>
        </Hidden>
    )
}