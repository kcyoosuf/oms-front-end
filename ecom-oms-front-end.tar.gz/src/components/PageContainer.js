import React from 'react'
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
    page: {
        margin: "0 auto",
        minWidth: "90%",
        maxWidth: "1680px",
        padding: "8px",
    }
}))

export default ({ children }) => {
    const classes = useStyles();
    return (
        <div className={classes.page}>
            {children}
        </div>
    )
}